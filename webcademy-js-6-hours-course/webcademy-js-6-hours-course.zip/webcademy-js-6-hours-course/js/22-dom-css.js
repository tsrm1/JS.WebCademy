// ================================  Работа с CSS классами ===============================

/*
element.classList.add()

.add()
.remove()
.toggle()
.contains()

*/

document.querySelector('h2');
